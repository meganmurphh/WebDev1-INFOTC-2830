$(function() {
  var player = "one";
  var table = $('table');
  var messages = $('.messages');
  var turn = $('.turn');
  showNextPlayer(turn, player);
  
  $('td').click(function() {
    td = $(this);
    var state = defState(td);
    if(!state) {
      var pattern = definePattern(player);
      changeState(td, pattern);
      if(checkIfPlayerWon(table, pattern)) {
        messages.html('Player ' + player + ' is the winner!');
        turn.html('');
      } else {
        player = setNextPlayer(player);
        showNextPlayer(turn, player);
      }
    } else {
      messages.html('This box is already checked.');
    }

  });
  
  $('.reset').click(function() {
    player = "one";
    messages.html('');
    reset(table);
    showNextPlayer(turn, player);
  });
  
});
  
  function defState(td) {
    if(td.hasClass('cross') || td.hasClass('circle')) {
      return 1;
    } else {
      return 0;
    }
  }
  
  function changeState(td, pattern) {
    return td.addClass(pattern);
  }
  
  function definePattern(player) {
    if(player == "one") {
      return 'cross';
    } else {
      return 'circle';
    }
  }
  
  function setNextPlayer(player) {
    if(player == "one") {
      return player = "two";
    } else {
      return player = "one";
    }
  }
  
  function showNextPlayer(turn, player) {
    turn.html("Player " + player + "'s turn:");
  }
  
  function checkIfPlayerWon(table, pattern) {
    var won = 0;
    if(table.find('.box1').hasClass(pattern) && table.find('.box2').hasClass(pattern) && table.find('.box3').hasClass(pattern)) {
      won = 1;
    } else if (table.find('.box1').hasClass(pattern) && table.find('.box4').hasClass(pattern) && table.find('.box7').hasClass(pattern)) {
      won = 1;
    } else if (table.find('.box1').hasClass(pattern) && table.find('.box5').hasClass(pattern) && table.find('.box9').hasClass(pattern)) {
      won = 1;
    } else if (table.find('.box4').hasClass(pattern) && table.find('.box5').hasClass(pattern) && table.find('.box6').hasClass(pattern)) {
      won = 1;
    } else if (table.find('.box7').hasClass(pattern) && table.find('.box8').hasClass(pattern) && table.find('.box9').hasClass(pattern)) {
      won = 1;
    } else if (table.find('.box2').hasClass(pattern) && table.find('.box5').hasClass(pattern) && table.find('.box8').hasClass(pattern)) {
      won = 1;
    } else if (table.find('.box3').hasClass(pattern) && table.find('.box6').hasClass(pattern) && table.find('.box9').hasClass(pattern)) {
      won = 1;
    } else if (table.find('.box3').hasClass(pattern) && table.find('.box5').hasClass(pattern) && table.find('.box7').hasClass(pattern)) {
      won = 1;
    }
    return won;
  }
  
  function reset(table) {
    table.find('td').each(function() {
      $(this).removeClass('circle').removeClass('cross');
    });
  }